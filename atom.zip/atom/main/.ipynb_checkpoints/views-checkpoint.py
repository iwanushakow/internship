from django.shortcuts import render
from .forms import TaskForm
import pandas as pd
from catboost import CatBoostClassifier
import catboost
import numpy as np

def func(request):
    score = ''
    mood = ''
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
#           using the model to score the comment            
            text = {'text': [form.cleaned_data['title']]}
            
            model = CatBoostClassifier()
            model.load_model('modelissimo')
            df = pd.DataFrame(text)
            rating = model.predict_proba(df)
            possible_ratings = [1, 2, 3, 4, 7, 8, 9, 10]
            rating =  model.classes_[np.argmax(rating[0])]
            score = rating
            mood = 'Отрицательное' if rating <= 4 else 'Положительное'
            
            
    form = TaskForm()
    return render(request, 'main/index.html', {"form": form, "score": score, "mood": mood})
