from django.shortcuts import render
from .forms import TaskForm
import pandas as pd
from catboost import CatBoostClassifier
import catboost
import numpy as np

def func(request):
    model = CatBoostClassifier()
    model.load_model('modelissimo')
    score = ''
    mood = ''
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            comment_text = form.cleaned_data['title'].lower()
            comment_text.replace("don't", "do not")
#           using the model to score the comment            
            text = {'text': [comment_text]}
            df = pd.DataFrame(text)
            rating = model.predict_proba(df)
            rating =  model.classes_[np.argmax(rating[0])]
            score = rating
            mood = 'Отрицательное' if rating <= 4 else 'Положительное'
            
            
    form = TaskForm()
    return render(request, 'main/index.html', {"form": form, "score": score, "mood": mood})
